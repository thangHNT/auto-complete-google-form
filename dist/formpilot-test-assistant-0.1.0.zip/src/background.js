"use strict";

importScripts("shared/core.js");

const Core = globalThis.FormPilotCore;
const verifiedSessions = new Map();
const MAX_TEST_RESPONSES = 10;

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function tabUrl(tab) {
  return String(tab?.url || tab?.pendingUrl || "");
}

async function waitForTabComplete(tabId, timeoutMs = 30000) {
  const existing = await chrome.tabs.get(tabId);
  if (existing.status === "complete") return existing;

  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Trang tải quá lâu. Hãy mở tab form và thử lại."));
    }, timeoutMs);

    function listener(updatedTabId, changeInfo, tab) {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(tab);
    }

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function waitForRedirectedForm(tabId, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const tab = await chrome.tabs.get(tabId);
    const url = tabUrl(tab);
    if (
      tab.status === "complete" &&
      (url.startsWith("https://docs.google.com/forms/") ||
        url.startsWith("https://accounts.google.com/"))
    ) {
      return tab;
    }
    await delay(200);
  }
  throw new Error("Không thể mở liên kết Google Form.");
}

async function ensureContentScript(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, { type: "PING" });
    if (response?.ok) return;
  } catch {
    // Tab có thể đã được mở trước khi extension được cài hoặc vừa điều hướng.
  }

  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["src/shared/core.js", "src/content.js"]
  });
}

async function sendToFormTab(tabId, message) {
  await ensureContentScript(tabId);
  return chrome.tabs.sendMessage(tabId, message);
}

async function scanTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const url = tabUrl(tab);

  if (url.startsWith("https://accounts.google.com/")) {
    return {
      ok: false,
      code: "LOGIN_REQUIRED",
      tabId,
      reason: "Google yêu cầu đăng nhập trước khi đọc biểu mẫu."
    };
  }

  const parsed = Core.parseGoogleFormUrl(url);
  if (!parsed.valid) {
    return { ok: false, code: "INVALID_FORM", tabId, reason: parsed.reason };
  }
  if (parsed.kind === "edit") {
    return {
      ok: false,
      code: "RESPONSE_LINK_REQUIRED",
      tabId,
      reason: "Hãy dùng liên kết xem trước hoặc liên kết dành cho người trả lời."
    };
  }

  const response = await sendToFormTab(tabId, { type: "SCAN_FORM" });
  if (!response?.ok) {
    return {
      ok: false,
      code: "SCAN_FAILED",
      tabId,
      reason: response?.reason || "Không thể quét biểu mẫu."
    };
  }

  if (!response.schema?.questions?.length) {
    return {
      ok: false,
      code: "NO_QUESTIONS",
      tabId,
      reason: "Không tìm thấy câu hỏi. Form có thể chưa được cấp quyền truy cập."
    };
  }

  return {
    ok: true,
    tabId,
    formUrl: url,
    schema: response.schema
  };
}

async function openAndScan(url) {
  const parsed = Core.parseGoogleFormUrl(url);
  if (!parsed.valid) return { ok: false, code: "INVALID_URL", reason: parsed.reason };

  const tab = await chrome.tabs.create({ url: parsed.canonicalUrl, active: false });
  try {
    await waitForRedirectedForm(tab.id);
    return scanTab(tab.id);
  } catch (error) {
    return { ok: false, code: "OPEN_FAILED", tabId: tab.id, reason: error.message };
  }
}

async function inspectOwnedPreview(editUrl) {
  const parsed = Core.parseGoogleFormUrl(editUrl);
  if (!parsed.valid || parsed.kind !== "edit") {
    return { ok: false, reason: "Liên kết xác minh phải là URL /edit của Google Form." };
  }

  const tab = await chrome.tabs.create({ url: parsed.canonicalUrl, active: false });
  try {
    await waitForTabComplete(tab.id);
    const current = await chrome.tabs.get(tab.id);
    if (tabUrl(current).startsWith("https://accounts.google.com/")) {
      return { ok: false, reason: "Hãy đăng nhập tài khoản có quyền chỉnh sửa form." };
    }

    const metadata = await sendToFormTab(tab.id, { type: "GET_EDITOR_METADATA" });
    if (!metadata?.ok || !metadata.metadata?.accessible) {
      return { ok: false, reason: "Tài khoản hiện tại không mở được trình chỉnh sửa form." };
    }

    const previewUrl = Core.previewUrlFromEdit(tabUrl(current));
    if (!previewUrl) {
      return { ok: false, reason: "Không thể tạo URL xem trước từ liên kết chỉnh sửa." };
    }

    await chrome.tabs.update(tab.id, { url: previewUrl });
    await waitForTabComplete(tab.id);
    const scan = await scanTab(tab.id);
    if (!scan.ok) return scan;

    return { ok: true, schema: scan.schema };
  } finally {
    try {
      await chrome.tabs.remove(tab.id);
    } catch {
      // Tab đã được đóng bởi người dùng.
    }
  }
}

async function verifyOwnership({ tabId, editUrl, targetSchema }) {
  const owned = await inspectOwnedPreview(editUrl);
  if (!owned.ok) return owned;

  const comparison = Core.compareSchemas(targetSchema, owned.schema);
  if (!comparison.match) {
    return { ok: false, reason: comparison.reason, comparison };
  }

  const token = crypto.randomUUID();
  verifiedSessions.set(token, {
    tabId,
    fingerprint: targetSchema.fingerprint,
    createdAt: Date.now()
  });

  return { ok: true, token, comparison };
}

async function notifyProgress(payload) {
  try {
    await chrome.runtime.sendMessage({ type: "RUN_PROGRESS", ...payload });
  } catch {
    // Workspace có thể đã bị đóng trong lúc chạy.
  }
}

async function waitAfterSubmit(tabId, previousUrl, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  let observedLoading = false;

  while (Date.now() < deadline) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === "loading") observedLoading = true;
      if (
        tab.status === "complete" &&
        (observedLoading || tabUrl(tab) !== previousUrl)
      ) {
        return tab;
      }
    } catch {
      throw new Error("Tab Google Form đã bị đóng.");
    }
    await delay(150);
  }

  throw new Error("Không nhận được xác nhận sau khi gửi form.");
}

async function runForm({
  tabId,
  formUrl,
  schema,
  answers,
  count,
  autoSubmit,
  ownerToken
}) {
  const runCount = Number.parseInt(count, 10);
  if (!Number.isInteger(runCount) || runCount < 1 || runCount > MAX_TEST_RESPONSES) {
    return {
      ok: false,
      reason: `Số lượt kiểm thử phải từ 1 đến ${MAX_TEST_RESPONSES}.`
    };
  }

  if (runCount > 1) {
    const session = verifiedSessions.get(ownerToken);
    if (
      !session ||
      session.tabId !== tabId ||
      session.fingerprint !== schema.fingerprint
    ) {
      return {
        ok: false,
        reason: "Cần xác minh quyền chỉnh sửa form trước khi gửi nhiều lượt."
      };
    }
  }

  const missing = Core.validateRequiredAnswers(schema, answers);
  if (missing.length > 0) {
    return {
      ok: false,
      reason: `Chưa trả lời ${missing.length} câu bắt buộc.`,
      missing
    };
  }

  if (autoSubmit && schema.hasNextPage) {
    return {
      ok: false,
      reason: "MVP chưa tự động gửi form nhiều trang hoặc có phân nhánh."
    };
  }

  for (let index = 0; index < runCount; index += 1) {
    if (index > 0) {
      await chrome.tabs.update(tabId, { url: formUrl });
      await waitForTabComplete(tabId);
    }

    const fillResult = await sendToFormTab(tabId, {
      type: "FILL_FORM",
      schema,
      answers
    });
    if (!fillResult?.ok) {
      return { ok: false, reason: fillResult?.reason || "Không thể điền biểu mẫu." };
    }

    const failedRequired = (fillResult.report || []).filter((item) => {
      const question = schema.questions.find((candidate) => candidate.id === item.id);
      return question?.required && !item.ok;
    });
    if (failedRequired.length > 0) {
      return {
        ok: false,
        reason: "Một số câu bắt buộc không thể tự động điền.",
        report: fillResult.report
      };
    }

    await notifyProgress({ current: index + 1, total: runCount, stage: "filled" });

    if (autoSubmit) {
      const beforeSubmit = tabUrl(await chrome.tabs.get(tabId));
      const submitResult = await sendToFormTab(tabId, { type: "SUBMIT_FORM" });
      if (!submitResult?.ok) {
        return {
          ok: false,
          reason: submitResult?.reason || "Không thể gửi biểu mẫu."
        };
      }
      await waitAfterSubmit(tabId, beforeSubmit);
      await notifyProgress({ current: index + 1, total: runCount, stage: "submitted" });
    }
  }

  await chrome.tabs.update(tabId, { active: true });
  return {
    ok: true,
    completed: runCount,
    submitted: Boolean(autoSubmit)
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
      case "OPEN_AND_SCAN":
        return openAndScan(message.url);
      case "RESCAN_TAB":
        await waitForTabComplete(message.tabId);
        return scanTab(message.tabId);
      case "ACTIVATE_TAB":
        await chrome.tabs.update(message.tabId, { active: true });
        return { ok: true };
      case "VERIFY_OWNER":
        return verifyOwnership(message);
      case "RUN_FORM":
        return runForm(message);
      default:
        return { ok: false, reason: "Thông điệp không được hỗ trợ." };
    }
  })()
    .then(sendResponse)
    .catch((error) => sendResponse({ ok: false, reason: error.message }));

  return true;
});
